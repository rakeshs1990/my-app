'use strict';

module.exports = function(Catalog) {

};
