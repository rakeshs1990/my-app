export default (server) => {
  // enable authentication
  server.enableAuth();
};
