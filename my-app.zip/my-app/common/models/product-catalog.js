'use strict';

module.exports = function(Productcatalog) {

};
